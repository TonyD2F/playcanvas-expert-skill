import * as pc from 'playcanvas';
import { CameraControls } from 'playcanvas/scripts/esm/camera-controls.mjs';
import { createApp } from './app.js';
import { applyCinematicLook, addStudioLights } from './look.js';
import { buildDemoScene } from './scene.js';

const canvas = document.getElementById('application');
const app = await createApp(canvas, { splats: false });
window.__app = app;                               // handy for verification tooling

const { spheres } = buildDemoScene(app);
addStudioLights(app);

const camera = new pc.Entity('camera');
camera.addComponent('camera', { fov: 40, clearColor: new pc.Color(0.02, 0.025, 0.04), nearClip: 0.1, farClip: 100 });
camera.setPosition(0, 2.2, 7);
camera.addComponent('script');
camera.script.create(CameraControls, { properties: { focusPoint: new pc.Vec3(0, 0.8, 0) } });
app.root.addChild(camera);

applyCinematicLook(app, camera, { taa: false });

let t = 0;
app.on('update', (dt) => {
    t += Math.min(dt, 1 / 20);
    spheres.forEach((s, i) => s.setLocalPosition(
        Math.cos(t * 0.4 + i * 1.57) * 2.2, 0.8 + Math.sin(t + i) * 0.15, Math.sin(t * 0.4 + i * 1.57) * 2.2));
});

app.once('frameend', () => {
    document.getElementById('loading').classList.add('done');
    window.__ready = true;
});
