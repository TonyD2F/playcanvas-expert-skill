import * as pc from 'playcanvas';

/** Procedural showpiece scene: no external assets, so it renders offline. Replace with your GLB. */
export function buildDemoScene(app) {
    app.scene.ambientLight = new pc.Color(0.08, 0.09, 0.13);

    const floor = new pc.Entity('floor');
    floor.addComponent('render', { type: 'plane' });
    floor.setLocalScale(30, 1, 30);
    const fm = new pc.StandardMaterial();
    fm.diffuse = new pc.Color(0.04, 0.045, 0.06);
    fm.useMetalness = true; fm.metalness = 0.2; fm.gloss = 0.75;
    fm.update();
    floor.render.material = fm;
    app.root.addChild(floor);

    const spheres = [];
    const hues = [[1, 0.35, 0.2], [0.2, 0.7, 1], [0.7, 0.3, 1], [0.3, 1, 0.6]];
    hues.forEach((h, i) => {
        const e = new pc.Entity(`orb${i}`);
        e.addComponent('render', { type: 'sphere', castShadows: true });
        const m = new pc.StandardMaterial();
        m.useMetalness = true; m.metalness = 1; m.gloss = 0.85;
        m.diffuse = new pc.Color(h[0], h[1], h[2]);
        m.emissive = new pc.Color(h[0], h[1], h[2]);
        m.emissiveIntensity = i === 0 ? 14 : 0.15;      // one HDR-bright orb drives the bloom
        m.update();
        e.render.material = m;
        e.setLocalPosition(Math.cos(i * 1.57) * 2.2, 0.8, Math.sin(i * 1.57) * 2.2);
        e.setLocalScale(1.1, 1.1, 1.1);
        app.root.addChild(e);
        spheres.push(e);
    });
    return { floor, spheres };
}
