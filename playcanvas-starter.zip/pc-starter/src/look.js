import * as pc from 'playcanvas';

/** HDR cinematic preset. Returns the CameraFrame; tweak then call frame.update(). */
export function applyCinematicLook(app, cameraEntity, opts = {}) {
    const { bloom = 0.012, ssao = true, taa = false, vignette = 0.35 } = opts;
    const frame = new pc.CameraFrame(app, cameraEntity.camera);
    frame.rendering.toneMapping = pc.TONEMAP_NEUTRAL;
    frame.rendering.samples = taa ? 1 : 4;
    frame.rendering.sharpness = taa ? 0.4 : 0;
    frame.taa.enabled = taa;
    frame.bloom.intensity = bloom;                 // >0 enables bloom (no bloom.enabled flag)
    frame.ssao.type = ssao ? pc.SSAOTYPE_COMBINE : pc.SSAOTYPE_NONE;
    frame.ssao.intensity = 0.5;
    frame.grading.enabled = true;
    frame.grading.contrast = 1.05;
    frame.grading.saturation = 1.1;
    frame.vignette.intensity = vignette;
    frame.update();                                // required after any change
    return frame;
}

/** Key light with shadows + cool rim; IBL should be set separately (app.scene.envAtlas). */
export function addStudioLights(app) {
    const key = new pc.Entity('key');
    key.addComponent('light', {
        type: 'directional', color: new pc.Color(1, 0.95, 0.88), intensity: 2.2,
        castShadows: true, shadowResolution: 2048, shadowDistance: 14,
        shadowType: pc.SHADOW_PCF3, normalOffsetBias: 0.05, shadowBias: 0.2
    });
    key.setEulerAngles(48, 35, 0);                 // lights shine along local -Y: aim with Euler, not lookAt
    app.root.addChild(key);

    const rim = new pc.Entity('rim');
    rim.addComponent('light', { type: 'directional', color: new pc.Color(0.45, 0.6, 1), intensity: 1.2 });
    rim.setEulerAngles(30, -150, 0);
    app.root.addChild(rim);
    return { key, rim };
}
