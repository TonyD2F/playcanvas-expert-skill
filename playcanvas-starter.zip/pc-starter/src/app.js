import * as pc from 'playcanvas';

/**
 * Create the app: WebGPU if available (falls back to WebGL2), only the systems used.
 * Pass { splats: true } to register gsplat support; { physics: true } expects Ammo loaded first.
 */
export async function createApp(canvas, { splats = false, physics = false, antialias = false } = {}) {
    const device = await pc.createGraphicsDevice(canvas, {
        deviceTypes: [pc.DEVICETYPE_WEBGPU],
        antialias,
        powerPreference: 'high-performance'
    });
    device.maxPixelRatio = Math.min(window.devicePixelRatio || 1, 2);

    const o = new pc.AppOptions();
    o.graphicsDevice = device;
    o.componentSystems = [
        pc.RenderComponentSystem, pc.CameraComponentSystem, pc.LightComponentSystem,
        pc.ScriptComponentSystem,
        ...(splats ? [pc.GSplatComponentSystem] : []),
        ...(physics ? [pc.RigidBodyComponentSystem, pc.CollisionComponentSystem] : [])
    ];
    o.resourceHandlers = [
        pc.TextureHandler, pc.ContainerHandler, pc.ScriptHandler,
        ...(splats ? [pc.GSplatHandler] : [])
    ];

    const app = new pc.AppBase(canvas);
    app.init(o);
    app.setCanvasFillMode(pc.FILLMODE_FILL_WINDOW);
    app.setCanvasResolution(pc.RESOLUTION_AUTO);
    window.addEventListener('resize', () => app.resizeCanvas());
    app.start();
    return app;
}

/** Load a list of pc.Asset and resolve when all are ready. */
export function loadAssets(app, assets) {
    return new Promise((resolve, reject) => {
        const loader = new pc.AssetListLoader(assets, app.assets);
        loader.on('error', reject);
        loader.load(resolve);
    });
}
