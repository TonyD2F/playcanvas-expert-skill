import test from 'node:test';
import assert from 'node:assert/strict';
import * as pc from 'playcanvas';

function headlessApp() {
    const canvas = { width: 1, height: 1 };
    const o = new pc.AppOptions();
    o.graphicsDevice = new pc.NullGraphicsDevice(canvas);
    o.componentSystems = [pc.ScriptComponentSystem, pc.CameraComponentSystem, pc.LightComponentSystem];
    const app = new pc.AppBase(canvas);
    app.init(o);
    app.start();
    return app;
}

test('scripts run on app.update and entities move', () => {
    const app = headlessApp();
    class Spin extends pc.Script { static scriptName = 'spin'; update(dt) { this.entity.rotate(0, 90 * dt, 0); } }
    const e = new pc.Entity('e');
    e.addComponent('script');
    e.script.create(Spin);
    app.root.addChild(e);
    for (let i = 0; i < 60; i++) app.update(1 / 60);
    assert.ok(Math.abs(e.getEulerAngles().y) > 1);
    app.destroy();
});

test('conventions: forward is -Z, up is +Y', () => {
    const e = new pc.Entity();
    assert.ok(Math.abs(e.forward.x) < 1e-6 && Math.abs(e.forward.y) < 1e-6 && Math.abs(e.forward.z + 1) < 1e-6);
    assert.equal(e.up.y, 1);
});

test('CameraFrame accepts the preset property names', async () => {
    const app = headlessApp();
    const cam = new pc.Entity('c'); cam.addComponent('camera'); app.root.addChild(cam);
    const { applyCinematicLook } = await import('../src/look.js');
    const f = applyCinematicLook(app, cam, { taa: true });
    assert.equal(f.taa.enabled, true);
    assert.equal(f.rendering.samples, 1);
    assert.ok(f.bloom.intensity > 0);
    app.destroy();
});
