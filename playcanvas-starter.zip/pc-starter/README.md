# PlayCanvas starter

Vite + PlayCanvas 2.x. WebGPU first (WebGL2 fallback), HDR `CameraFrame` look, studio lights, procedural demo scene (no external assets), shipped `CameraControls` orbit rig.

    npm install
    npm run dev        # http://localhost:5173
    npm test           # headless Node tests (NullGraphicsDevice), no GPU needed
    npm run build      # production bundle in dist/

Browser verification (needs Playwright + Chromium): `npm i -D playwright && npx playwright install chromium`,
then `npm run build && npx vite preview --port 4173 &` and `npm run verify`. It reports console errors, fps and a blank-canvas check.

Structure: `src/app.js` (device + app bootstrap), `src/look.js` (post-processing + lights), `src/scene.js` (demo content), `src/main.js` (wiring). Swap `scene.js` for your GLB (`ContainerHandler` is already registered) or pass `{ splats: true }` to `createApp` for Gaussian splats.
