// Browser verification: console errors, non-blank canvas, fps. UNTESTED in the authoring sandbox
// (no browser there). Requires: npm i -D playwright && npx playwright install chromium
// Usage: npm run build && npx vite preview --port 4173 &  then  npm run verify
import { chromium } from 'playwright';
import { readFileSync } from 'node:fs';

const url = process.argv[2] || 'http://localhost:4173';
const browser = await chromium.launch({
    args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']
});
const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
const problems = [];
page.on('console', m => { if (['error', 'warning'].includes(m.type())) problems.push(`${m.type()}: ${m.text()}`); });
page.on('pageerror', e => problems.push(`pageerror: ${e.message}`));

await page.goto(url);
await page.waitForFunction(() => window.__ready === true, null, { timeout: 30000 });
await page.waitForTimeout(1500);

const stats = await page.evaluate(() => new Promise(resolve => {
    const a = window.__app; let frames = 0; const t0 = performance.now();
    const h = () => { frames++; };
    a.on('frameend', h);
    setTimeout(() => { a.off('frameend', h); resolve({ fps: +(frames / ((performance.now() - t0) / 1000)).toFixed(1) }); }, 3000);
}));

await page.screenshot({ path: 'verify-screenshot.png' });
const png = readFileSync('verify-screenshot.png');
const distinct = new Set(); for (let i = 200; i < png.length; i += 997) distinct.add(png[i]);

console.log(JSON.stringify({ ...stats, distinctSamples: distinct.size, problems }, null, 2));
await browser.close();
process.exit(problems.length || distinct.size < 20 ? 1 : 0);
